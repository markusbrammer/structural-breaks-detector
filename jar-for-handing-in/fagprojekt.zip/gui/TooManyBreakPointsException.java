package gui;

public class TooManyBreakPointsException extends Exception {

    public TooManyBreakPointsException(String errorMessage) {
        super(errorMessage);
    }
}
