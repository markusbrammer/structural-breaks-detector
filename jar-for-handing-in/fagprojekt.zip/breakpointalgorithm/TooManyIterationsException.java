package breakpointalgorithm;

public class TooManyIterationsException extends Exception {

    public TooManyIterationsException(String errorMessage) {
        super(errorMessage);
    }
}
