package fitness.rectangle;

import fitness.BreakPoint;

public class RectBreakPoint extends BreakPoint {
    char symbol = '!';

    @Override
    public String toString() {
        return symbol + "";
    }

}