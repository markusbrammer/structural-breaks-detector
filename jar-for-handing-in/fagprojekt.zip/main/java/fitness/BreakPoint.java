package fitness;

public abstract class BreakPoint {

}
