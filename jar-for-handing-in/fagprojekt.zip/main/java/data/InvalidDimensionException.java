package data;

public class InvalidDimensionException extends Exception {

    public InvalidDimensionException(String errorMessage) {
        super(errorMessage);
    }
}
