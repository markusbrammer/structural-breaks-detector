//import bp.BreakPointProcedures;
//import ga.Population;
//
//public class TestPopulation {
//
//    public static void main(String[] args) {
//        int noOfIndviduals = 6;
//        int individualSize = 10;
//        int maxNoOfBreakPoints = 3;
//        Population population = BreakPointProcedures.initPopulation(noOfIndviduals, individualSize, maxNoOfBreakPoints);
//        for (int i = 0; i < noOfIndviduals; i++) {
//            System.out.println(population.getIndividual(i));
//        }
//    }
//
//}
