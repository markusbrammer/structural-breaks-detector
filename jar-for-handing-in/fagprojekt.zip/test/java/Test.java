public class Test {

    @org.junit.Test
    public void test() {
        int test1 = 3;
        int test2 = 4;
        System.out.println(2. * test1 / test2);
    }
}